def collate_vod_batch(batch):
    pts_list = []
    gt_labels_3d_list = []
    gt_bboxes_3d_list = []
    meta_list = []
    camera_data_list = []
    
    for idx, sample in enumerate(batch):
        pts_list.append(sample['lidar_data'])
        gt_labels_3d_list.append(sample['gt_labels_3d'])
        gt_bboxes_3d_list.append(sample['gt_bboxes_3d'])
        meta_list.append(sample['meta'])
        
        # Handle camera data
        if 'camera_data' in sample and sample['camera_data']:
            camera_data_list.append(sample['camera_data'])
    
    result_dict = dict(
        pts = pts_list,
        gt_labels_3d = gt_labels_3d_list,
        gt_bboxes_3d = gt_bboxes_3d_list,
        metas = meta_list
    )
    
    # Add camera data if available
    if camera_data_list:
        import torch
        # Stack camera data
        camera_batch = {
            'img_prev': torch.stack([c['img_prev'] for c in camera_data_list], dim=0),
            'img_current': torch.stack([c['img_current'] for c in camera_data_list], dim=0)
        }
        result_dict['camera_data'] = camera_batch
    
    return result_dict
    