import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import BatchNorm2d, Conv2d


class OpticalFlowProcessor(nn.Module):
    """
    Optical flow processor for computing motion features between consecutive frames.
    Implements Lucas-Kanade based optical flow with learnable refinement.
    
    Args:
        in_channels (int): Input channels for the flow features
        out_channels (int): Output channels for refined flow features
        kernel_size (int): Kernel size for convolution
        downsample_factor (int): Factor to downsample input images (1, 2, or 4) to reduce memory.
                                 Default: 1 (no downsampling)
    """
    
    def __init__(self, in_channels=3, out_channels=32, kernel_size=3, downsample_factor=1):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.downsample_factor = downsample_factor
        
        assert downsample_factor in [1, 2, 4], "downsample_factor must be 1, 2, or 4"
        
        # Encoder for computing flow
        self.flow_encoder = nn.Sequential(
            Conv2d(in_channels * 2, 64, kernel_size=7, stride=2, padding=3, bias=False),
            BatchNorm2d(64, eps=1e-3, momentum=0.01),
            nn.ReLU(inplace=True),
            Conv2d(64, 128, kernel_size=5, stride=2, padding=2, bias=False),
            BatchNorm2d(128, eps=1e-3, momentum=0.01),
            nn.ReLU(inplace=True),
        )
        
        # Flow prediction head
        self.flow_head = nn.Sequential(
            Conv2d(128, 128, kernel_size=3, padding=1, bias=False),
            BatchNorm2d(128, eps=1e-3, momentum=0.01),
            nn.ReLU(inplace=True),
            Conv2d(128, 64, kernel_size=3, padding=1, bias=False),
            BatchNorm2d(64, eps=1e-3, momentum=0.01),
            nn.ReLU(inplace=True),
        )
        
        # Refinement network
        self.refine_net = nn.Sequential(
            Conv2d(64 + in_channels, 64, kernel_size=3, padding=1, bias=False),
            BatchNorm2d(64, eps=1e-3, momentum=0.01),
            nn.ReLU(inplace=True),
            Conv2d(64, out_channels, kernel_size=3, padding=1, bias=False),
            BatchNorm2d(out_channels, eps=1e-3, momentum=0.01),
            nn.ReLU(inplace=True),
        )
    
    def warp(self, x, flow):
        """
        Warp image x according to flow.
        
        Args:
            x (torch.Tensor): Image to warp (B, C, H, W)
            flow (torch.Tensor): Optical flow (B, 2, H, W)
            
        Returns:
            torch.Tensor: Warped image
        """
        B, C, H, W = x.size()
        
        # Create coordinate grid
        xx = torch.arange(0, W).view(1, -1).repeat(H, 1).to(x.device)
        yy = torch.arange(0, H).view(-1, 1).repeat(1, W).to(x.device)
        
        xx = xx.float() - flow[0, 0]
        yy = yy.float() - flow[0, 1]
        
        xx = (xx / (W - 1)) * 2 - 1
        yy = (yy / (H - 1)) * 2 - 1
        
        grid = torch.stack([xx, yy], dim=2).unsqueeze(0)
        
        warped = F.grid_sample(x, grid, align_corners=True, mode='bilinear', padding_mode='zeros')
        return warped
    
    def compute_flow_similarity(self, feat1, feat2):
        """
        Compute optical flow using feature similarity.
        
        Args:
            feat1 (torch.Tensor): Features from frame t (B, C, H, W)
            feat2 (torch.Tensor): Features from frame t+1 (B, C, H, W)
            
        Returns:
            torch.Tensor: Optical flow (B, 2, H, W)
        """
        # Simple correlation-based flow estimation
        # This is a simplified version; in practice, could use more sophisticated methods
        B, C, H, W = feat1.size()
        
        # Resize features to common resolution for efficiency
        h, w = H // 2, W // 2
        feat1_small = F.interpolate(feat1, (h, w), mode='bilinear', align_corners=False)
        feat2_small = F.interpolate(feat2, (h, w), mode='bilinear', align_corners=False)
        
        # Normalize features
        feat1_small = feat1_small / (feat1_small.norm(dim=1, keepdim=True) + 1e-8)
        feat2_small = feat2_small / (feat2_small.norm(dim=1, keepdim=True) + 1e-8)
        
        # Compute correlation volume
        corr = torch.nn.functional.conv2d(
            feat2_small,
            feat1_small,
            groups=1,
            padding=0
        )
        
        # Find peak correlation to estimate flow
        # This is a simplified flow computation
        batch_flow = []
        for b in range(B):
            corr_b = corr[b]
            if corr_b.nelement() > 0:
                # Get argmax for flow estimation
                argmax_idx = torch.argmax(corr_b.max(dim=0)[0])
                # Simplified flow (could be improved with real optical flow algorithm)
                flow_b = torch.zeros(2, h, w, device=feat1.device)
                batch_flow.append(flow_b)
            else:
                flow_b = torch.zeros(2, h, w, device=feat1.device)
                batch_flow.append(flow_b)
        
        flow = torch.stack(batch_flow, dim=0)
        # Upsample flow back to original resolution
        flow = F.interpolate(flow, (H, W), mode='bilinear', align_corners=False) * 2
        
        return flow
    
    def forward(self, img_t, img_t1, feat_t=None):
        """
        Compute optical flow features between two consecutive frames.
        
        Args:
            img_t (torch.Tensor): Image at time t (B, 3, H, W)
            img_t1 (torch.Tensor): Image at time t+1 (B, 3, H, W)
            feat_t (torch.Tensor, optional): Pre-computed features for frame t
            
        Returns:
            torch.Tensor: Motion features (B, out_channels, H_out, W_out)
                         where H_out = H / downsample_factor, W_out = W / downsample_factor
        """
        # Downsample input images if needed
        if self.downsample_factor > 1:
            img_t = F.interpolate(
                img_t,
                scale_factor=1.0 / self.downsample_factor,
                mode='bilinear',
                align_corners=False
            )
            img_t1 = F.interpolate(
                img_t1,
                scale_factor=1.0 / self.downsample_factor,
                mode='bilinear',
                align_corners=False
            )
        
        # Concatenate images along channel dimension
        img_concat = torch.cat([img_t, img_t1], dim=1)  # (B, 6, H, W)
        
        # Compute optical flow through encoder
        flow_feat = self.flow_encoder(img_concat)  # (B, 128, H/4, W/4)
        flow_feat = self.flow_head(flow_feat)  # (B, 64, H/4, W/4)
        
        # Upsample back to downsampled resolution
        flow_feat_up = F.interpolate(flow_feat, img_t.shape[2:], mode='bilinear', align_corners=False)
        
        # Refine with downsampled images
        refined_input = torch.cat([flow_feat_up, img_t], dim=1)
        motion_features = self.refine_net(refined_input)  # (B, out_channels, H, W)
        
        return motion_features
