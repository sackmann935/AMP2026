import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models
from torch.nn import BatchNorm2d, Conv2d


class CameraBackbone(nn.Module):
    """
    Camera backbone for extracting features from mono camera images.
    Uses ResNet18 as a backbone and outputs multi-scale features.
    
    Args:
        in_channels (int): Input channels (3 for RGB images)
        out_channels (int): Output feature channels
        pretrained (bool): Whether to use pretrained weights
        downsample_factor (int): Factor to downsample input images (1, 2, or 4) to reduce memory.
                                Default: 1 (no downsampling)
    """
    
    def __init__(self, in_channels=3, out_channels=128, pretrained=True, downsample_factor=1):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.downsample_factor = downsample_factor
        
        assert downsample_factor in [1, 2, 4], "downsample_factor must be 1, 2, or 4"
        
        # Load pretrained ResNet18
        resnet = models.resnet18(pretrained=pretrained)
        
        # Extract layers for multi-scale features
        # Layer 1: 64 channels, 64x64 spatial
        self.layer1 = nn.Sequential(
            resnet.conv1,
            resnet.bn1,
            resnet.relu,
            resnet.maxpool,
            resnet.layer1
        )
        
        # Layer 2: 128 channels, 32x32 spatial
        self.layer2 = resnet.layer2
        
        # Layer 3: 256 channels, 16x16 spatial
        self.layer3 = resnet.layer3
        
        # Feature projection layers to unify output dimensions
        self.proj_layer1 = Conv2d(64, out_channels, kernel_size=1, bias=False)
        self.bn_layer1 = BatchNorm2d(out_channels, eps=1e-3, momentum=0.01)
        self.relu1 = nn.ReLU(inplace=True)
        
        self.proj_layer2 = Conv2d(128, out_channels, kernel_size=1, bias=False)
        self.bn_layer2 = BatchNorm2d(out_channels, eps=1e-3, momentum=0.01)
        self.relu2 = nn.ReLU(inplace=True)
        
        self.proj_layer3 = Conv2d(256, out_channels, kernel_size=1, bias=False)
        self.bn_layer3 = BatchNorm2d(out_channels, eps=1e-3, momentum=0.01)
        self.relu3 = nn.ReLU(inplace=True)
    
    def forward(self, x):
        """
        Forward pass for camera backbone.
        
        Args:
            x (torch.Tensor): Input images of shape (B, C, H, W) where H=1216, W=1936
            
        Returns:
            list: Multi-scale feature maps with unified output channels (downsampled by downsample_factor)
        """
        # Downsample input images if needed
        if self.downsample_factor > 1:
            x = F.interpolate(
                x,
                scale_factor=1.0 / self.downsample_factor,
                mode='bilinear',
                align_corners=False
            )
        
        # Layer 1 features (64 channels)
        feat1_raw = self.layer1(x)  # (B, 64, H/4, W/4) after internal downsampling
        feat1 = self.proj_layer1(feat1_raw)
        feat1 = self.bn_layer1(feat1)
        feat1 = self.relu1(feat1)
        
        # Layer 2 features - input is raw layer1 output (64 channels), not projected
        feat2_raw = self.layer2(feat1_raw)  # (B, 128, H/8, W/8)
        feat2 = self.proj_layer2(feat2_raw)
        feat2 = self.bn_layer2(feat2)
        feat2 = self.relu2(feat2)
        
        # Layer 3 features - input is raw layer2 output (128 channels), not projected
        feat3_raw = self.layer3(feat2_raw)  # (B, 256, H/16, W/16)
        feat3 = self.proj_layer3(feat3_raw)
        feat3 = self.bn_layer3(feat3)
        feat3 = self.relu3(feat3)
        
        return [feat1, feat2, feat3]
