import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import Conv2d, BatchNorm2d


class CrossAttentionFusionModule(nn.Module):
    """
    Single-head sparse cross-attention fusion between radar features (Query)
    and camera features (Key, Value).
    
    This module fuses PointPillars radar features with camera features using
    cross-attention to produce enhanced 3D detection features.
    
    Args:
        radar_feat_channels (int): Number of channels in radar features from PointPillars
        camera_feat_channels (int): Number of channels in camera features (after projection)
        output_channels (int): Number of output channels
        num_heads (int): Always 1 for sparse attention
        spatial_shape (tuple): Spatial shape of features (H, W)
        attention_dropout (float): Dropout rate for attention weights
        spatial_downsample (int): Downsample spatial dimensions for attention computation
    """
    
    def __init__(self,
                 radar_feat_channels=384,
                 camera_feat_channels=128,
                 output_channels=384,
                 num_heads=1,
                 spatial_shape=(160, 160),
                 attention_dropout=0.1,
                 feature_dropout=0.1,
                 spatial_downsample=2):
        super().__init__()
        
        assert num_heads == 1, "Only single head attention is supported for sparse attention"
        
        self.radar_feat_channels = radar_feat_channels
        self.camera_feat_channels = camera_feat_channels
        self.output_channels = output_channels
        self.num_heads = num_heads
        self.spatial_shape = spatial_shape
        self.head_dim = output_channels // num_heads
        self.spatial_downsample = spatial_downsample  # Downsample for attention computation
        
        # Query projection from radar features
        self.query_proj = nn.Sequential(
            Conv2d(radar_feat_channels, output_channels, kernel_size=1, bias=False),
            BatchNorm2d(output_channels, eps=1e-3, momentum=0.01),
            nn.ReLU(inplace=True)
        )
        
        # Key projection from camera features
        self.key_proj = nn.Sequential(
            Conv2d(camera_feat_channels, output_channels, kernel_size=1, bias=False),
            BatchNorm2d(output_channels, eps=1e-3, momentum=0.01),
            nn.ReLU(inplace=True)
        )
        
        # Value projection from camera features
        self.value_proj = nn.Sequential(
            Conv2d(camera_feat_channels, output_channels, kernel_size=1, bias=False),
            BatchNorm2d(output_channels, eps=1e-3, momentum=0.01),
            nn.ReLU(inplace=True)
        )
        
        # Output projection
        self.out_proj = nn.Sequential(
            Conv2d(output_channels, output_channels, kernel_size=1, bias=False),
            BatchNorm2d(output_channels, eps=1e-3, momentum=0.01),
            nn.ReLU(inplace=True)
        )
        
        self.attention_dropout = nn.Dropout(attention_dropout)
        self.feature_dropout = nn.Dropout2d(feature_dropout)
        self.temperature = nn.Parameter(torch.tensor(1.0 / (self.head_dim ** 0.5)))
        
    def sparse_attention(self, q, k, v, sparse_mask=None):
        """
        Compute efficient sparse cross-attention with spatial downsampling.
        
        Args:
            q (torch.Tensor): Query features (B, C, H, W)
            k (torch.Tensor): Key features (B, C, H, W)
            v (torch.Tensor): Value features (B, C, H, W)
            sparse_mask (torch.Tensor, optional): Sparse attention mask
            
        Returns:
            torch.Tensor: Attended features (B, C, H, W)
        """
        B, C, H, W = q.size()
        original_shape = (H, W)
        
        # Downsample for efficient attention computation
        if self.spatial_downsample > 1:
            q = F.interpolate(q, scale_factor=1.0/self.spatial_downsample, mode='bilinear', align_corners=False)
            k = F.interpolate(k, scale_factor=1.0/self.spatial_downsample, mode='bilinear', align_corners=False)
            v = F.interpolate(v, scale_factor=1.0/self.spatial_downsample, mode='bilinear', align_corners=False)
        
        B, C, H_s, W_s = q.size()
        
        # Flatten spatial dimensions for attention
        q_flat = q.reshape(B, C, -1).transpose(1, 2)  # (B, H*W, C)
        k_flat = k.reshape(B, C, -1).transpose(1, 2)  # (B, H*W, C)
        v_flat = v.reshape(B, C, -1).transpose(1, 2)  # (B, H*W, C)
        
        # Compute attention scores with reduced spatial dimensionality
        scores = torch.matmul(q_flat, k_flat.transpose(1, 2))  # (B, H*W, H*W)
        scores = scores * self.temperature
        
        # Softmax normalization
        attention_weights = F.softmax(scores, dim=-1)
        attention_weights = self.attention_dropout(attention_weights)
        
        # Apply attention to values
        output = torch.matmul(attention_weights, v_flat)  # (B, H*W, C)
        output = output.transpose(1, 2).reshape(B, C, H_s, W_s)  # (B, C, H_s, W_s)
        
        # Upsample back to original resolution
        if self.spatial_downsample > 1:
            output = F.interpolate(output, size=original_shape, mode='bilinear', align_corners=False)
        
        return output
    
    def _get_sparse_indices(self, H, W, sparsity=0.25):
        """
        Get sparse sampling indices for efficient attention.
        
        Args:
            H (int): Height of feature map
            W (int): Width of feature map
            sparsity (float): Fraction of points to sample
            
        Returns:
            list: List of sampled (h, w) indices
        """
        num_samples = int((H * W) * sparsity)
        indices = torch.randperm(H * W)[:num_samples]
        sparse_indices = [(idx // W, idx % W) for idx in indices]
        return sparse_indices
    
    def _create_sparse_pattern(self, B, H, W, sparse_samples, window_size=3):
        """
        Create sparse attention pattern with local windows around sampled points.
        
        Args:
            B (int): Batch size
            H (int): Height
            W (int): Width
            sparse_samples (list): List of sparse sample indices
            window_size (int): Local window size
            
        Returns:
            torch.Tensor: Sparse attention mask (B, H*W, H*W)
        """
        mask = torch.zeros(B, H * W, H * W, dtype=torch.bool)
        
        for h, w in sparse_samples:
            # Add local window around this point
            h_start = max(0, h - window_size // 2)
            h_end = min(H, h + window_size // 2 + 1)
            w_start = max(0, w - window_size // 2)
            w_end = min(W, w + window_size // 2 + 1)
            
            for hi in range(h_start, h_end):
                for wi in range(w_start, w_end):
                    q_idx = h * W + w
                    k_idx = hi * W + wi
                    mask[:, q_idx, k_idx] = True
        
        # Enable all attention for sparse samples themselves (to compute global context)
        for h, w in sparse_samples:
            q_idx = h * W + w
            mask[:, q_idx, :] = True
        
        return mask
    
    def forward(self, radar_features, camera_features):
        """
        Forward pass for cross-attention fusion.
        
        Args:
            radar_features (torch.Tensor): Radar features from PointPillars (B, 384, H, W)
            camera_features (torch.Tensor): Camera features (B, C, H, W)
            
        Returns:
            torch.Tensor: Fused features (B, output_channels, H, W)
        """
        # Project to same dimensions
        q = self.query_proj(radar_features)  # (B, C, H, W)
        k = self.key_proj(camera_features)   # (B, C, H, W)
        v = self.value_proj(camera_features) # (B, C, H, W)
        
        # Apply sparse cross-attention
        attended = self.sparse_attention(q, k, v)  # (B, C, H, W)
        
        # Output projection
        output = self.out_proj(attended)  # (B, output_channels, H, W)
        output = self.feature_dropout(output)
        
        # Residual connection
        output = output + q
        
        return output


class CrossAttentionFusion(nn.Module):
    """
    Wrapper module for cross-attention fusion that handles multi-scale features.
    
    Args:
        radar_feat_channels (int): Channels of radar features
        camera_feat_channels (int): Channels of camera features
        output_channels (int): Output channels
        spatial_shapes (list): List of spatial shapes for multi-scale features
        spatial_downsample (int): Spatial downsampling factor for memory efficiency
    """
    
    def __init__(self,
                 radar_feat_channels=384,
                 camera_feat_channels=128,
                 output_channels=384,
                 spatial_shapes=[(160, 160)],
                 attention_dropout=0.1,
                 feature_dropout=0.1,
                 spatial_downsample=2):
        super().__init__()
        
        self.fusion_modules = nn.ModuleList([
            CrossAttentionFusionModule(
                radar_feat_channels=radar_feat_channels,
                camera_feat_channels=camera_feat_channels,
                output_channels=output_channels,
                num_heads=1,
                spatial_shape=shape,
                attention_dropout=attention_dropout,
                feature_dropout=feature_dropout,
                spatial_downsample=spatial_downsample
            )
            for shape in spatial_shapes
        ])
    
    def forward(self, radar_features, camera_features):
        """
        Fuse radar and camera features.
        
        Args:
            radar_features (torch.Tensor): Radar features (B, 384, H, W)
            camera_features (torch.Tensor): Camera features (B, C, H, W)
            
        Returns:
            torch.Tensor: Fused features
        """
        # If camera features need to be upsampled/downsampled to match radar
        if camera_features.shape[-2:] != radar_features.shape[-2:]:
            camera_features = F.interpolate(
                camera_features,
                size=radar_features.shape[-2:],
                mode='bilinear',
                align_corners=False
            )
        
        # Apply fusion
        fused = self.fusion_modules[0](radar_features, camera_features)
        
        return fused
